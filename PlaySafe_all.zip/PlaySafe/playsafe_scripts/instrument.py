# Test-only copy: scenes start on demand (window.__lz), the frame loop does not render,
# every scene's build time goes to window.__T and the scene object to window.__S.
import sys
src, dst = sys.argv[1], sys.argv[2]
s = open(src, encoding='utf-8').read()
def rep(a, b):
    global s
    assert s.count(a) == 1, a[:60]
    s = s.replace(a, b)
rep('function lazy(host,f){', 'function lazy(host,f){(window.__lz=window.__lz||[]).push(f);return;')
rep('function scene(host,o,build){',
    'function scene(h,o,b){const t=performance.now(),S=scene0(h,o,b);(window.__T=window.__T||[]).push(performance.now()-t);(window.__S=window.__S||[]).push(S);return S}\nfunction scene0(host,o,build){')
rep('S.upd.forEach(f=>f(dt,t));r.render(sc,cam);', 'S.upd.forEach(f=>f(dt,t));if(!window.__noLoop)r.render(sc,cam);')
rep('<script src="https://cdnjs', '<script>window.__noLoop=true</script><script src="https://cdnjs')
open(dst, 'w', encoding='utf-8', newline='').write(s)
print('ok')
