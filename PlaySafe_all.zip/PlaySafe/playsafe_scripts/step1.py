import re, sys
P = sys.argv[1]
s = open(P, encoding='utf-8').read()

# ---------- 1. remove unused dictionary entries ----------
REMOVE = ['Chest sensor', 'High', 'RISK LEVEL: MEDIUM', 'Movement anomaly detected', 'Risk level: Medium',
  'Without data, nobody notices the change.', 'Long recovery', 'A small problem becomes a serious injury.',
  'Risk assessment', 'The situation is rated Low, Medium or High.', 'Staff are warned before it gets serious.',
  'Motion, impact and heart rate. More sensors later.', 'Sensor module',
  'A small removable module in the shirt collects movement and physical-load data.',
  'Sensors sit in a small removable module, so the shirt stays light, flat and washable.',
  'Motion sensor', 'Tracks movement changes.', 'Heart-rate sensor', 'Monitors heart rate.', 'Impact sensor',
  'Detects strong impacts.', 'Temperature sensor', 'Tracks body temperature.', 'Motion tracking',
  'Analyzes movement patterns.', 'Removable module in a washable compression shirt. Light, flat, no extra weight.',
  'MVP · chest strap', 'Future', 'AI injury risk detection',
  'PlaySafe compares each player with their own normal movement. It flags unusual changes. It does not predict injuries or give a diagnosis.',
  'Shoulder', 'Lower back', 'Hamstring', 'Knee', 'Ankle', 'Movement load', 'Risk status', 'Light', 'Low', 'Medium',
  'Detected', 'CHECK REQUIRED', 'Potential risk only. Requires assessment by medical staff.', 'Movement anomaly',
  'Risk level', 'Risk level:', 'MEDIUM', 'LOW', 'Pause player and perform a professional assessment.',
  'Recovery status', 'GOOD', 'RECOVERY RECOMMENDED', 'NORMAL RECOVERY', 'Less risk',
  'Earlier identification of potential problems.', 'Information during training and matches.',
  'Unusual movement detected.', 'Impact: HIGH · Movement change: DETECTED',
  'An AI-powered smart football system that monitors player movement, detects dangerous impacts and helps teams identify potential injury risks before they become serious.',
  'Removable module · 2 motion sensors · under 20 g · built for training first']
a, b = s.index('const DD=['), s.index('const D=Object.fromEntries')
dd = s[a:b]
for k in REMOVE:
    pat = r"\[(['\"])" + re.escape(k) + r"\1(?:,(['\"]).*?\2){3}\],?\n?"
    m = list(re.finditer(pat, dd))
    if len(m) != 1:
        sys.exit(f'DD remove {k!r}: {len(m)} matches')
    dd = dd[:m[0].start()] + dd[m[0].end():]
s = s[:a] + dd + s[b:]

# ---------- 2. code / HTML replacements: (old, new, expected count) ----------
R = [
 ('An AI-powered smart football system that monitors player movement, detects dangerous impacts and helps teams identify potential injury risks before they become serious.',
  'An AI-powered smart football system that monitors player movement, detects strong impacts and flags when a player moves differently from their own normal after an impact, so staff can check early.', 1),
 ('Removable module · 2 motion sensors · under 20 g · built for training first',
  '2 removable motion modules · upper back and pelvis · built for training first', 1),
 ('<b>IMPACT DETECTED</b>Chest sensor', '<b>IMPACT DETECTED</b>Upper-back sensor · demo', 1),
 ('<b>PLAYER LOAD 82%</b>High', '<b>PLAYER LOAD 82%</b>Of personal max · demo', 1),
 ('<b>RISK LEVEL: MEDIUM</b>Check recommended', '<b>STATUS: CHECK</b>Check recommended · demo', 1),
 ('<li>Movement anomaly detected</li><li>Risk level: Medium</li>',
  '<li>Movement differs from personal normal</li><li>Status: CHECK</li>', 1),
 ("['Player continues','Without data, nobody notices the change.'],['Long recovery','A small problem becomes a serious injury.']",
  "['Player continues','Small changes are easy to miss by eye.'],['Late check','Problems are noticed later than they could be.']", 1),
 ("['Sensor module','A small removable module in the shirt collects movement and physical-load data.']",
  "['Sensor modules','Two small removable modules collect movement and impact data.']", 1),
 ("['Risk assessment','The situation is rated Low, Medium or High.']",
  "['Status','The player is marked Normal, Monitor or Check.']", 1),
 ("'Staff are warned before it gets serious.'", "'Staff get an early signal to check.'", 1),
 ("'Motion, impact and heart rate. More sensors later.'",
  "'Two motion sensors: upper back and pelvis. Heart rate and temperature: optional, later.'", 1),
 ("['Less risk','Earlier identification of potential problems.']",
  "['Earlier checks','Unusual movement is flagged early for staff.']", 1),
 ("'Information during training and matches.'", "'Live information during training.'", 1),
 # sensors: only two, both on the back
 ("const SN=[['f','Motion sensor','Tracks movement changes.',45,45],['f','Heart-rate sensor','Monitors heart rate.',112,72],['f','Impact sensor','Detects strong impacts.',85,72],['f','Temperature sensor','Tracks body temperature.',100,150],['b','Motion tracking','Analyzes movement patterns.',100,70],['b','Impact sensor','Detects strong impacts.',150,45],['b','Motion sensor','Tracks movement changes.',100,150]];",
  "const SN=[['b','Upper-back sensor','Between the shoulder blades, in a shirt pocket. Detects impacts, falls, sprints and changes of direction.',100,48],['b','Pelvis sensor','Lower back, near the sacrum. Tracks step pattern, accelerations and changes of direction.',100,190]];", 1),
 ('<path d="M-55 45H45M255 72H112M-55 150H100"', '<path d="M-55 48H88M255 190H112"', 1),
 ("$('#hv').insertAdjacentHTML('afterbegin',jer('f',1));", "$('#hv').insertAdjacentHTML('afterbegin',jer('b',1));", 1),
 ('Removable module in a washable compression shirt. Light, flat, no extra weight.',
  'Removable module. The clothing goes in the wash, the module does not.', 2),
 ("jv('f');document.querySelectorAll('#side button')", "jv('b');document.querySelectorAll('#side button')", 1),
 ('<button class="on" data-s="f">Front</button><button data-s="b">Back</button>',
  '<button data-s="f">Front</button><button class="on" data-s="b">Back</button>', 1),
 ('<h3>Select a sensor</h3><p>Sensors sit in a small removable module, so the shirt stays light, flat and washable.</p>',
  '<h3>Select a sensor</h3><p>Two small removable modules on the back: upper back and pelvis. No sensors on the front.</p><p><span class="st m">Future / optional</span> Optional later: heart-rate chest strap, temperature sensor.</p>', 1),
 ("S.tg=b+Math.round((r-b)/(2*Math.PI))*2*Math.PI}});", "S.tg=b+Math.round((r-b)/(2*Math.PI))*2*Math.PI};S.root.rotation.y=Math.PI});", 1),
 ("const TG={'Motion sensor':'MVP','Impact sensor':'MVP','Motion tracking':'MVP','Heart-rate sensor':'MVP · chest strap','Temperature sensor':'Future'};",
  "const TG={'Upper-back sensor':'MVP','Pelvis sensor':'MVP'};", 1),
 # zones -> movement change after impact
 ('<h2 class="rv">AI injury risk detection</h2><p class="rv" style="max-width:720px">PlaySafe compares each player with their own normal movement. It flags unusual changes. It does not predict injuries or give a diagnosis.</p>',
  '<h2 class="rv">Movement change after impact</h2><p class="rv" style="max-width:720px">PlaySafe compares each player with their own normal movement and flags clear changes after an impact. It does not predict injuries, give a diagnosis or locate an injury in a specific body part.</p>', 1),
 ("const Z=[['Shoulder',138,85,62,'Light','None','Normal'],['Lower back',100,170,58,'Low','None','Normal'],['Hamstring',113,225,81,'Medium','Detected','Check required'],['Knee',125,265,78,'Medium','Detected','Check required'],['Ankle',128,330,69,'Low','None','Normal']];",
  "const Z=[['Upper-back sensor',100,95,[['Impacts today','+2','Monitor'],['Trunk lean','+12%','Monitor']],'Monitor'],['Pelvis sensor',100,182,[['Step symmetry (left / right)','−15%','Check'],['Accelerations and direction changes','−9%','Monitor']],'Check']],ZK={Normal:'',Monitor:'m',Check:'c'};", 1),
 ("function zi(i){const z=Z[i],w=z[6]!='Normal';document.querySelectorAll('.zn').forEach((c,j)=>c.classList.toggle('s',j==i));$('#zi').innerHTML=`<h3>${z[0]}</h3><div class=row><span>Movement load</span><b>${z[3]}%</b></div><div class=row><span>Impact</span><b>${z[4]}</b></div><div class=row><span>Movement change</span><b>${z[5]}</b></div><div class=row><span>Risk status</span><b><span class=\"st ${w?'c':''}\">${z[6].toUpperCase()}</span></b></div><p style=\"margin-top:12px;font-size:14px\">Potential risk only. Requires assessment by medical staff.</p>`}",
  "function zi(i){const z=Z[i];document.querySelectorAll('.zn').forEach((c,j)=>c.classList.toggle('s',j==i));$('#zi').innerHTML=`<h3>${z[0]}</h3><span class=\"st ${ZK[z[4]]}\">${z[4].toUpperCase()}</span><div class=row style=\"margin-top:10px\"><span>Signal</span><b>vs personal normal</b></div>`+z[3].map(r=>`<div class=row><span>${r[0]}</span><b>${r[1]} <span class=\"st ${ZK[r[2]]}\">${r[2].toUpperCase()}</span></b></div>`).join('')+`<p style=\"margin-top:12px;font-size:14px\">Demo data. Potential risk only. Requires assessment by staff.</p>`}", 1),
 ("zi(c.dataset.i)});zi(2);", "zi(c.dataset.i)});zi(1);", 1),
 ("const pos=[[.28,1.45,.02],[0,1.0,-.2],[.095,.54,-.085],[.095,.39,.07],[.095,.09,.02]]", "const pos=[[0,1.36,-.21],[0,.86,-.2]]", 1),
 ("const c=z[6]=='Normal'?GR:0xff5a4d", "const c=z[4]=='Check'?0xff5a4d:z[4]=='Monitor'?0xf5c542:GR", 1),
 ("let za=2;", "let za=1;", 1),
 # players
 ("'Light','No','Low'", "'Minor','No','Low'", 2),
 ("'Detected','Yes','Medium'", "'Strong','Yes','Medium'", 1),
 ("<div class=row><span>Movement anomaly</span><b>${p[7]}</b></div><div class=row><span>Risk level</span><b>${p[8].toUpperCase()}</b></div><p style=\"margin-top:12px;color:#fff\">${p[8]=='Medium'?'Pause player and perform a professional assessment.':p[3]>=75?'Keep monitoring workload.':'No action needed. Keep monitoring.'}</p>",
  "<div class=row><span>Differs from personal normal</span><b>${p[7]}</b></div><p style=\"margin-top:12px;color:#fff\">${s[1]=='CHECK'?'Check recommended. Staff decide what to do.':s[1]=='MONITOR'?'Keep monitoring workload.':'No action needed. Keep monitoring.'}</p>", 1),
 ('<div class="gl" id="pf"></div></div></section>',
  '<div class="gl" id="pf"></div></div><p class="rv" style="margin-top:10px;font-size:14px">Load = % of the player\'s personal maximum. Demo data.</p></section>', 1),
 # load + recovery
 ('<div class="gl"><b>GOOD</b><span>Recovery status</span></div></div>',
  '<div class="gl"><b style="color:#ff7468">CHECK</b><span>Status</span></div></div><p class="rv" style="font-size:14px;margin-top:-8px">Cards show this week. Load values are % of the player\'s personal maximum. Demo data.</p>', 1),
 ("'Lower','RECOMMENDED','RECOVERY RECOMMENDED','rgba(245,197,66,.15)','var(--wn)'", "'Lower','CHECK','CHECK','rgba(255,90,77,.15)','#ff7468'", 1),
 ("'Stable','OK','NORMAL RECOVERY'", "'Stable','OK','NORMAL'", 1),
 ("<span>Recovery status</span><b></b>", "<span>Status</span><b></b>", 1),
 # toast
 ('<p style="margin:4px 0">Unusual movement detected.<br>Impact: HIGH · Movement change: DETECTED</p><div>Risk level: <span class="st c" style="font-size:18px">MEDIUM</span></div><p style="margin:8px 0;color:#fff">CHECK RECOMMENDED</p>',
  '<p style="margin:4px 0">Strong impact.<br>Movement differs from personal normal</p><div>Status: <span class="st c" style="font-size:18px">CHECK</span></div><p style="margin:8px 0;color:#fff">CHECK RECOMMENDED</p><p style="font-size:12px;margin:0 0 8px">Demo data</p>', 1),
]
for old, new, n in R:
    c = s.count(old)
    if c != n:
        sys.exit(f'replace: expected {n}, found {c}: {old[:70]!r}')
    s = s.replace(old, new)

# ---------- 3. new dictionary entries (EN, RU, ZH, KK) ----------
NEW = r'''['An AI-powered smart football system that monitors player movement, detects strong impacts and flags when a player moves differently from their own normal after an impact, so staff can check early.','Умная футбольная система с ИИ: следит за движением игрока, фиксирует сильные удары и сообщает, если после удара игрок двигается иначе, чем обычно, чтобы персонал мог вовремя его проверить.','由 AI 驱动的智能足球系统：监测球员运动，识别强烈撞击；当球员在撞击后的动作与其自身常态不同时发出提示，方便工作人员及早检查。','ЖИ негізіндегі ақылды футбол жүйесі: ойыншының қозғалысын бақылайды, күшті соққыларды тіркейді және соққыдан кейін ойыншы әдеттегіден басқаша қозғалса, хабар береді — қызметкерлер оны ерте тексере алады.'],
['2 removable motion modules · upper back and pelvis · built for training first','2 съёмных модуля движения · верх спины и таз · сначала для тренировок','2 个可拆卸运动模块 · 上背部和骨盆 · 先用于训练','2 алынбалы қозғалыс модулі · жоғарғы арқа және жамбас · алдымен жаттығуға'],
['Upper-back sensor · demo','Датчик на верху спины · демо','上背部传感器 · 演示','Жоғарғы арқа датчигі · демо'],['Of personal max · demo','От личного максимума · демо','个人最大值占比 · 演示','Жеке максимумнан · демо'],['STATUS: CHECK','СТАТУС: ПРОВЕРКА','状态：检查','МӘРТЕБЕ: ТЕКСЕРУ'],['Check recommended · demo','Рекомендуется проверка · демо','建议检查 · 演示','Тексеру ұсынылады · демо'],
['Movement differs from personal normal','Движение отличается от личной нормы','运动与个人常态不同','Қозғалыс жеке нормадан өзгеше'],['Status: CHECK','Статус: проверка','状态：检查','Мәртебе: тексеру'],
['Small changes are easy to miss by eye.','Небольшие изменения легко пропустить на глаз.','细微变化单靠肉眼很容易漏掉。','Шағын өзгерістерді көзбен байқамай қалу оңай.'],['Late check','Поздняя проверка','检查太晚','Кеш тексеру'],['Problems are noticed later than they could be.','Проблемы замечают позже, чем могли бы.','问题被发现得比本可以的更晚。','Мәселелер мүмкін болғаннан кешірек байқалады.'],
['Sensor modules','Датчиковые модули','传感器模块','Датчик модульдері'],['Two small removable modules collect movement and impact data.','Два небольших съёмных модуля собирают данные о движении и ударах.','两个小型可拆卸模块收集运动和撞击数据。','Екі шағын алынбалы модуль қозғалыс пен соққы деректерін жинайды.'],
['Status','Статус','状态','Мәртебе'],['Status:','Статус:','状态：','Мәртебе:'],['The player is marked Normal, Monitor or Check.','Игроку присваивается статус «Норма», «Наблюдение» или «Проверка».','球员被标记为正常、关注或检查。','Ойыншыға «Қалыпты», «Бақылау» не «Тексеру» мәртебесі беріледі.'],
['Staff get an early signal to check.','Персонал заранее получает сигнал проверить игрока.','工作人员及早收到检查提示。','Қызметкерлер тексеру туралы ерте сигнал алады.'],
['Two motion sensors: upper back and pelvis. Heart rate and temperature: optional, later.','Два датчика движения: верх спины и таз. Пульс и температура — по желанию, позже.','两个运动传感器：上背部和骨盆。心率和体温为可选，后续加入。','Екі қозғалыс датчигі: жоғарғы арқа және жамбас. Пульс пен температура — қосымша, кейін.'],
['Upper-back sensor','Датчик на верху спины','上背部传感器','Жоғарғы арқа датчигі'],['Between the shoulder blades, in a shirt pocket. Detects impacts, falls, sprints and changes of direction.','Между лопатками, в кармашке футболки. Фиксирует удары, падения, спринты и смены направления.','位于两肩胛骨之间的球衣口袋中。检测撞击、摔倒、冲刺和变向。','Жауырындардың арасында, футболка қалтасында. Соққыларды, құлауды, спринттерді және бағыт өзгерісін анықтайды.'],
['Pelvis sensor','Датчик на тазу','骨盆传感器','Жамбас датчигі'],['Lower back, near the sacrum. Tracks step pattern, accelerations and changes of direction.','Низ спины, в районе крестца. Отслеживает характер шага, ускорения и смены направления.','位于下背部骶骨附近。追踪步态、加速和变向。','Арқаның төменгі бөлігі, сегізкөз маңы. Қадам сипатын, үдеуді және бағыт өзгерісін бақылайды.'],
['Removable module. The clothing goes in the wash, the module does not.','Съёмный модуль. Одежда идёт в стирку, модуль — нет.','可拆卸模块。衣服可以洗，模块不用洗。','Алынбалы модуль. Киім жуылады, модуль жуылмайды.'],
['Two small removable modules on the back: upper back and pelvis. No sensors on the front.','Два небольших съёмных модуля сзади: на верху спины и на тазу. Спереди датчиков нет.','背面有两个小型可拆卸模块：上背部和骨盆。正面没有传感器。','Артында екі шағын алынбалы модуль: жоғарғы арқада және жамбаста. Алдында датчик жоқ.'],
['Optional later: heart-rate chest strap, temperature sensor.','Позже по желанию: нагрудный ремень для пульса, датчик температуры.','后续可选：心率胸带、体温传感器。','Кейін қосымша: пульс өлшейтін кеуде белдігі, температура датчигі.'],['Future / optional','Позже / по желанию','未来 / 可选','Болашақта / қосымша'],
['Movement change after impact','Изменение движения после удара','撞击后的运动变化','Соққыдан кейінгі қозғалыс өзгерісі'],
['PlaySafe compares each player with their own normal movement and flags clear changes after an impact. It does not predict injuries, give a diagnosis or locate an injury in a specific body part.','PlaySafe сравнивает каждого игрока с его собственным обычным движением и отмечает заметные изменения после удара. Система не предсказывает травмы, не ставит диагноз и не определяет, где именно травма.','PlaySafe 将每位球员与其自身的正常运动对比，标记撞击后的明显变化。它不预测伤病、不做诊断，也不判断伤在身体哪个部位。','PlaySafe әр ойыншыны өзінің әдеттегі қозғалысымен салыстырып, соққыдан кейінгі айқын өзгерістерді белгілейді. Ол жарақатты болжамайды, диагноз қоймайды және жарақаттың дененің қай жерінде екенін анықтамайды.'],
['Signal','Сигнал','信号','Сигнал'],['vs personal normal','к личной норме','对比个人常态','жеке нормаға қарағанда'],['Impacts today','Удары сегодня','今日撞击','Бүгінгі соққылар'],['Trunk lean','Наклон корпуса','躯干倾斜','Дене еңкеюі'],['Step symmetry (left / right)','Симметрия шага (лево / право)','步态对称（左 / 右）','Қадам симметриясы (сол / оң)'],['Accelerations and direction changes','Ускорения и смены направления','加速与变向','Үдеу және бағыт өзгерісі'],
['Demo data. Potential risk only. Requires assessment by staff.','Демо-данные. Только возможный риск. Требуется оценка специалистов.','演示数据。仅为潜在风险，需由专业人员评估。','Демо-деректер. Тек ықтимал қауіп. Мамандардың бағалауы қажет.'],
['Minor','Слабый','轻微','Әлсіз'],['Strong','Сильный','强','Күшті'],['Differs from personal normal','Отличие от личной нормы','与个人常态不同','Жеке нормадан айырмашылық'],
['Check recommended. Staff decide what to do.','Рекомендуется проверка. Решение принимает персонал.','建议检查，由工作人员决定如何处理。','Тексеру ұсынылады. Шешімді қызметкерлер қабылдайды.'],
["Load = % of the player's personal maximum. Demo data.",'Нагрузка = % от личного максимума игрока. Демо-данные.','负荷 = 球员个人最大值的百分比。演示数据。','Жүктеме = ойыншының жеке максимумынан %. Демо-деректер.'],
["Cards show this week. Load values are % of the player's personal maximum. Demo data.",'Карточки — за эту неделю. Нагрузка указана в % от личного максимума игрока. Демо-данные.','卡片显示本周数据。负荷为球员个人最大值的百分比。演示数据。','Карточкалар — осы аптаға. Жүктеме ойыншының жеке максимумынан % түрінде. Демо-деректер.'],
['Strong impact.','Сильный удар.','强烈撞击。','Күшті соққы.'],
['Earlier checks','Более ранние проверки','更早检查','Ертерек тексеру'],['Unusual movement is flagged early for staff.','Необычное движение отмечается для персонала заранее.','异常运动会及早提示给工作人员。','Ерекше қозғалыс қызметкерлерге ерте белгіленеді.'],['Live information during training.','Информация в реальном времени на тренировках.','训练中的实时信息。','Жаттығу кезіндегі нақты уақыт ақпараты.']'''
end = "пилотта нақтыланады.']];"
if s.count(end) != 1:
    sys.exit('DD end marker not found')
s = s.replace(end, "пилотта нақтыланады.'],\n" + NEW + "];")
open(P, 'w', encoding='utf-8', newline='').write(s)
print('ok', len(s.encode('utf-8')))
