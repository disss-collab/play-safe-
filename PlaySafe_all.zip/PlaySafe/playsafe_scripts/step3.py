import sys
P = sys.argv[1]
s = open(P, encoding='utf-8').read()

def rep(old, new, n=1):
    global s
    c = s.count(old)
    if c != n:
        sys.exit(f'expected {n}, found {c}: {old[:70]!r}')
    s = s.replace(old, new)

# ---------- 3b. roadmap order ----------
V2 = ",['v2 · after the pilot','Anomaly-detection models trained on pilot data.']"
PILOT = "['Pilot','10–20 modules, about $100–200 each, tested with a club academy.']"
rep(V2, '')
rep(PILOT, PILOT + V2)

# ---------- 3a. CSS ----------
CSS = (".zs{display:flex;justify-content:space-between;align-items:baseline;gap:10px;margin-top:14px;font-size:15px;color:var(--m)}"
 ".zs b{font:800 24px 'Barlow Condensed',sans-serif;color:#fff}"
 "#zr{width:100%;accent-color:var(--g);margin:6px 0 4px;height:28px;cursor:pointer}"
 "#zc svg{width:100%;height:auto;display:block}"
 ".zf{font:600 15px/1.4 ui-monospace,Consolas,monospace;background:rgba(0,0,0,.35);border:1px solid var(--b);border-radius:8px;padding:10px 12px;margin:12px 0 4px;overflow-wrap:anywhere;color:#dfe9e3}.zf b{color:#fff}"
 ".zl{display:flex;flex-wrap:wrap;gap:6px 16px;font-size:13px;color:var(--m);margin-top:10px}"
 ".zl i{display:inline-block;width:10px;height:10px;border-radius:3px;margin-right:6px;vertical-align:-1px}.zl b{color:#fff;font-weight:500}"
 ".zn2{font-size:14px;margin:8px 0 0}\n")
rep('</style><script src="https://cdnjs', CSS + '</style><script src="https://cdnjs')

# ---------- 3a. HTML (inside #how, after the chain) ----------
HTML = ('<div id="c2" class="rv"></div>\n'
 '<div class="k rv" style="margin-top:70px">Personal normal + z-score · demo data</div><h2 class="rv">How AI v1 decides</h2>'
 '<p class="rv" style="max-width:720px">PlaySafe v1 does not guess injuries. It learns each player\'s normal from earlier sessions and measures how far today\'s movement is from it. Move the slider and switch players.</p>'
 '<div class="tg rv" id="zpl"><button class="on" data-p="9">Player 09</button><button data-p="7">Player 07</button></div>'
 '<div class="two rv"><div class="gl"><h3>Step symmetry (left / right)</h3><p style="font-size:14px">100% = left and right steps are the same.</p><div id="zc"></div>'
 '<div class="zl"><span><i style="height:2px;width:16px;border-radius:0;vertical-align:3px;background:#1fdc6a"></i>Personal normal</span>'
 '<span><i style="background:rgba(31,220,106,.35)"></i><b>NORMAL</b> z &gt; −2</span>'
 '<span><i style="background:rgba(245,197,66,.6)"></i><b>MONITOR</b> −3 &lt; z ≤ −2</span>'
 '<span><i style="background:rgba(255,90,77,.6)"></i><b>CHECK</b> z ≤ −3</span></div>'
 '<label class="zs" for="zr"><span>Step symmetry today</span><b id="zv">78%</b></label>'
 '<input type="range" id="zr" min="60" max="100" step="1" value="78" aria-valuetext="78%">'
 '<p class="zn2">Keep the same value and switch players. The status changes because each player has their own normal.</p></div>'
 '<div class="gl"><div id="zpn"></div>'
 '<p class="zn2">Only a drop in symmetry raises the status.</p>'
 '<p class="zn2">Demo thresholds, to be tuned on real data.</p>'
 '<p class="zn2">v1 uses simple statistics, not a trained AI model. v2 after the pilot: anomaly-detection models.</p>'
 '<p class="zn2" style="color:var(--g2)">Demo data</p></div></div>')
rep('<div id="c2" class="rv"></div>', HTML)

# ---------- 3a. JS ----------
JS = r'''// AI v1: personal normal + z-score (demo data, one-sided: only a drop raises the status)
const ZD={9:[92,95,90,93,89,94,92,91,95,90,93,90],7:[85,80,90,82,88,79,91,84,86,81,89,85]};let zp=9;
const r1=x=>Math.round(x*10)/10,fz=(x,d)=>(x<0?'−':'')+Math.abs(x).toFixed(d);
function zr(){const a=ZD[zp],n=a.length,mu=a.reduce((t,x)=>t+x,0)/n,sd=Math.sqrt(a.reduce((t,x)=>t+(x-mu)**2,0)/n),
 m=r1(mu),sg=r1(sd),v=+$('#zr').value,z=r1((v-m)/sg),ch=Math.round((v-m)/m*100),
 st=z<=-3?['c','CHECK','#ff5a4d']:z<=-2?['m','MONITOR','#f5c542']:['','NORMAL','#1fdc6a'],
 Y=x=>20+(100-Math.max(60,Math.min(100,x)))/40*270,X=i=>70+i*38,y2=Y(m-2*sg),y3=Y(m-3*sg);
 $('#zc').innerHTML=`<svg viewBox="0 0 600 340" aria-hidden="true">`+[60,70,80,90,100].map(t=>`<line x1="50" x2="590" y1="${Y(t)}" y2="${Y(t)}" stroke="rgba(255,255,255,.07)"/><text x="42" y="${Y(t)+6}" text-anchor="end" font-size="18" fill="#9db1a5">${t}</text>`).join('')
 +`<rect x="50" y="20" width="540" height="${y2-20}" fill="rgba(31,220,106,.09)"/><rect x="50" y="${y2}" width="540" height="${y3-y2}" fill="rgba(245,197,66,.16)"/><rect x="50" y="${y3}" width="540" height="${Math.max(0,290-y3)}" fill="rgba(255,90,77,.13)"/>`
 +`<line x1="50" x2="590" y1="${Y(m)}" y2="${Y(m)}" stroke="#1fdc6a" stroke-width="2.5"/><line x1="50" x2="590" y1="290" y2="290" stroke="rgba(255,255,255,.25)"/><line x1="516" x2="516" y1="20" y2="290" stroke="rgba(255,255,255,.2)" stroke-dasharray="4 5"/>`
 +a.map((x,i)=>`<circle cx="${X(i)}" cy="${Y(x)}" r="7" fill="#1fdc6a" opacity=".85"/>`).join('')
 +`<line x1="553" x2="553" y1="${Y(m)}" y2="${Y(v)}" stroke="${st[2]}" stroke-width="2.5" stroke-dasharray="5 4"/><circle cx="553" cy="${Y(v)}" r="19" fill="${st[2]}" opacity=".22"/><circle cx="553" cy="${Y(v)}" r="10" fill="${st[2]}" stroke="#fff" stroke-width="2"/>`
 +`<text x="${(X(0)+X(11))/2}" y="324" text-anchor="middle" font-size="20" fill="#9db1a5">Earlier sessions</text><text x="553" y="324" text-anchor="middle" font-size="20" fill="#fff">Today</text></svg>`;
 $('#zpn').innerHTML=`<h3>Player ${String(zp).padStart(2,'0')}</h3><div class=row><span>Personal normal (12 sessions)</span><b>${m.toFixed(1)}%</b></div><div class=row><span>Usual spread (SD)</span><b>${sg.toFixed(1)}</b></div><div class=row><span>Today after impact</span><b>${v}%</b></div><div class=row><span>Change vs normal</span><b>${ch>0?'+':''}${fz(ch,0)}%</b></div><div class=zf>z = (${v} − ${m.toFixed(1)}) / ${sg.toFixed(1)} = <b>${fz(z,1)}</b></div><div class=row><span>Status</span><b><span class="st ${st[0]}">${st[1]}</span></b></div><p class=zn2>z shows how many usual spreads today is away from the player's normal.</p>`}
$('#zr').oninput=()=>{const t=$('#zr').value+'%';$('#zv').textContent=t;$('#zr').setAttribute('aria-valuetext',t);zr()};
document.querySelectorAll('#zpl button').forEach(b=>b.onclick=()=>{document.querySelectorAll('#zpl button').forEach(x=>x.classList.toggle('on',x==b));zp=+b.dataset.p;zr()});zr();
// demo
'''
rep('\n// demo\n', '\n' + JS)

# ---------- dictionary ----------
NEW = r'''['Personal normal + z-score · demo data','Личная норма + z-оценка · демо-данные','个人常态 + z 分数 · 演示数据','Жеке норма + z-бағалау · демо-деректер'],['How AI v1 decides','Как решает ИИ v1','AI v1 如何判断','ЖИ v1 қалай шешеді'],
["PlaySafe v1 does not guess injuries. It learns each player's normal from earlier sessions and measures how far today's movement is from it. Move the slider and switch players.",'PlaySafe v1 не угадывает травмы. Система определяет норму каждого игрока по прошлым тренировкам и измеряет, насколько сегодняшнее движение от неё отличается. Двигайте ползунок и переключайте игроков.','PlaySafe v1 不猜测伤病。它根据以往训练得出每位球员的常态，并衡量今天的运动与常态相差多少。拖动滑块并切换球员试试。','PlaySafe v1 жарақатты болжап айтпайды. Ол әр ойыншының нормасын бұрынғы жаттығулар бойынша анықтап, бүгінгі қозғалыстың одан қаншалықты алшақ екенін өлшейді. Жүгірткіні жылжытып, ойыншыларды ауыстырып көріңіз.'],
['100% = left and right steps are the same.','100% = левый и правый шаг одинаковы.','100% = 左右步完全一致。','100% = сол және оң қадам бірдей.'],['Step symmetry today','Симметрия шага сегодня','今日步态对称','Бүгінгі қадам симметриясы'],
['Earlier sessions','Прошлые тренировки','以往训练','Бұрынғы жаттығулар'],['Today','Сегодня','今天','Бүгін'],
['Keep the same value and switch players. The status changes because each player has their own normal.','Оставьте то же значение и переключите игрока. Статус меняется, потому что у каждого игрока своя норма.','保持数值不变，切换球员。状态会改变，因为每位球员都有自己的常态。','Мәнді өзгертпей, ойыншыны ауыстырыңыз. Мәртебе өзгереді, өйткені әр ойыншының өз нормасы бар.'],
['Personal normal (12 sessions)','Личная норма (12 тренировок)','个人常态（12 次训练）','Жеке норма (12 жаттығу)'],['Usual spread (SD)','Обычный разброс (SD)','常规波动（标准差）','Әдеттегі ауытқу (SD)'],['Today after impact','Сегодня после удара','今天撞击后','Бүгін соққыдан кейін'],['Change vs normal','Изменение к норме','相对常态的变化','Нормаға қарағанда өзгеріс'],
["z shows how many usual spreads today is away from the player's normal.",'z показывает, на сколько обычных разбросов сегодняшнее значение отстоит от нормы игрока.','z 表示今天的数值偏离球员常态多少个常规波动。','z бүгінгі мәннің ойыншы нормасынан неше әдеттегі ауытқуға алшақ екенін көрсетеді.'],
['Only a drop in symmetry raises the status.','Статус повышает только снижение симметрии.','只有对称性下降才会提高状态等级。','Мәртебені тек симметрияның төмендеуі көтереді.'],
['Demo thresholds, to be tuned on real data.','Демо-пороги, будут настроены на реальных данных.','演示阈值，将根据真实数据调整。','Демо-шектер, нақты деректерде бапталады.'],
['v1 uses simple statistics, not a trained AI model. v2 after the pilot: anomaly-detection models.','v1 использует простую статистику, а не обученную модель ИИ. v2 после пилота: модели поиска аномалий.','v1 使用简单统计，而非训练好的 AI 模型。试点之后的 v2：异常检测模型。','v1 оқытылған ЖИ моделін емес, қарапайым статистиканы қолданады. Пилоттан кейінгі v2: ауытқуларды іздеу модельдері.']'''
a = s.index('const D=Object.fromEntries')
end = s.rindex('];', 0, a)
s = s[:end].rstrip().rstrip(',') + ',\n' + NEW + s[end:]
open(P, 'w', encoding='utf-8', newline='').write(s)
print('ok', len(s.encode('utf-8')))
