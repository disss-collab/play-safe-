import sys
P = sys.argv[1]
s = open(P, encoding='utf-8').read()

def rep(old, new, n=1):
    global s
    c = s.count(old)
    if c != n:
        sys.exit(f'expected {n}, found {c}: {old[:80]!r}')
    s = s.replace(old, new)

# ---------- 1. players: shared geometries and materials ----------
rep("""function man(kit,n){
 const g=new TH.Group(),M=(c,r,m,e)=>new TH.MeshStandardMaterial({color:c,roughness:r,metalness:m||0,emissive:e||0});
 const dim=c=>new TH.Color(c).multiplyScalar(.22),jm=M(kit.shirt,.62,.04,dim(kit.shirt)),sk=M(0xd8a77f,.8),hr=M(0x1a120d,.9),sh=M(kit.shorts,.7),so=M(kit.sock,.75,0,dim(kit.sock)),bt=M(0x0c0c0c,.35,.25);""",
"""// geometries and materials are made once and shared by all players (core + halo stay per player: the demo recolors them)
const GC={},MC={},gq=(T,...a)=>GC[T+a.join()]||(GC[T+a.join()]=new TH[T](...a)),mq=(k,f)=>MC[k]||(MC[k]=f());
function man(kit,n){
 const g=new TH.Group(),M=(c,r,m,e)=>new TH.MeshStandardMaterial({color:c,roughness:r,metalness:m||0,emissive:e||0});
 const dim=c=>new TH.Color(c).multiplyScalar(.22),jm=mq('j'+kit.shirt,()=>M(kit.shirt,.62,.04,dim(kit.shirt))),sk=mq('sk',()=>M(0xd8a77f,.8)),hr=mq('hr',()=>M(0x1a120d,.9)),sh=mq('s'+kit.shorts,()=>M(kit.shorts,.7)),so=mq('o'+kit.sock,()=>M(kit.sock,.75,0,dim(kit.sock))),bt=mq('bt',()=>M(0x0c0c0c,.35,.25));""")
# geometry constructors inside man() -> shared
a = s.index('function man(kit,n){')
b = s.index(' return g}', a)
body = s[a:b]
for T in ('CylinderGeometry', 'SphereGeometry', 'BoxGeometry', 'PlaneGeometry'):
    body = body.replace(f'new TH.{T}(', f"gq('{T}',")
if 'new TH.' + 'CylinderGeometry' in body:
    sys.exit('man: geometry left')
# number plate material: shared per number + kit colour
old_nm = "new TH.MeshBasicMaterial({map:textTex(n||'09',kit.num,128,128,'800 96px sans-serif'),transparent:true})"
if body.count(old_nm) != 1:
    sys.exit('man: number material not found')
body = body.replace(old_nm, "mq('n'+(n||'09')+kit.num,()=>new TH.MeshBasicMaterial({map:textTex(n||'09',kit.num,128,128,'800 96px sans-serif'),transparent:true}))")
s = s[:a] + body + s[b:]

# ---------- 4. jersey: heavy parts made once, reused by the second jersey ----------
rep("const geo=new TH.ExtrudeGeometry(s,{depth:.3,bevelEnabled:true,bevelThickness:.05,bevelSize:.05,bevelSegments:3,curveSegments:16});geo.translate(0,0,-.15);",
    "const geo=JC.geo||(JC.geo=new TH.ExtrudeGeometry(s,{depth:.3,bevelEnabled:true,bevelThickness:.05,bevelSize:.05,bevelSegments:3,curveSegments:16}).translate(0,0,-.15));")
rep("const body=new TH.Mesh(geo,new TH.MeshStandardMaterial({color:0x0e2c19,roughness:.72,metalness:.04,emissive:0x04200f,bumpMap:knitTex(),bumpScale:.7}));",
    "const body=new TH.Mesh(geo,JC.bm||(JC.bm=new TH.MeshStandardMaterial({color:0x0e2c19,roughness:.72,metalness:.04,emissive:0x04200f,bumpMap:knitTex(),bumpScale:.7})));")
rep("g.add(new TH.LineSegments(new TH.EdgesGeometry(geo,38),new TH.LineBasicMaterial({color:GR,transparent:true,opacity:.35})));",
    "g.add(new TH.LineSegments(JC.eg||(JC.eg=new TH.EdgesGeometry(geo,38)),JC.lm||(JC.lm=new TH.LineBasicMaterial({color:GR,transparent:true,opacity:.35}))));")
rep("const tr=new TH.MeshStandardMaterial({color:0x14a24c,roughness:.5,emissive:0x0a5a26,emissiveIntensity:.8});",
    "const tr=JC.tr||(JC.tr=new TH.MeshStandardMaterial({color:0x14a24c,roughness:.5,emissive:0x0a5a26,emissiveIntensity:.8}));")
rep("g.add(new TH.Mesh(new TH.TubeGeometry(new TH.QuadraticBezierCurve3(new TH.Vector3(cp[0],cp[1],.2),new TH.Vector3(cm[0],cm[1]-.1,.22),new TH.Vector3(cq[0],cq[1],.2)),24,.045,8,false),tr));",
    "g.add(new TH.Mesh(JC.t1||(JC.t1=new TH.TubeGeometry(new TH.QuadraticBezierCurve3(new TH.Vector3(cp[0],cp[1],.2),new TH.Vector3(cm[0],cm[1]-.1,.22),new TH.Vector3(cq[0],cq[1],.2)),24,.045,8,false)),tr));")
rep("g.add(new TH.Mesh(new TH.TubeGeometry(new TH.QuadraticBezierCurve3(new TH.Vector3(h1[0],h1[1]+.03,0),new TH.Vector3(hm[0],hm[1]-.05,0),new TH.Vector3(h2[0],h2[1]+.03,0)),24,.2,8,false),tr));",
    "g.add(new TH.Mesh(JC.t2||(JC.t2=new TH.TubeGeometry(new TH.QuadraticBezierCurve3(new TH.Vector3(h1[0],h1[1]+.03,0),new TH.Vector3(hm[0],hm[1]-.05,0),new TH.Vector3(h2[0],h2[1]+.03,0)),24,.2,8,false)),tr));")
rep("const nm=new TH.Mesh(new TH.PlaneGeometry(1.1,1.1),new TH.MeshBasicMaterial({map:textTex('09','#d8ffe6',256,256,'800 190px sans-serif'),transparent:true}));",
    "const nm=new TH.Mesh(JC.ng||(JC.ng=new TH.PlaneGeometry(1.1,1.1)),JC.nm||(JC.nm=new TH.MeshBasicMaterial({map:textTex('09','#d8ffe6',256,256,'800 190px sans-serif'),transparent:true})));")
rep("const wm=new TH.Mesh(new TH.PlaneGeometry(1.5,.3),new TH.MeshBasicMaterial({map:textTex('PLAYSAFE','#b6f7cf',512,100,'800 70px sans-serif'),transparent:true}));",
    "const wm=new TH.Mesh(JC.wg||(JC.wg=new TH.PlaneGeometry(1.5,.3)),JC.wm||(JC.wm=new TH.MeshBasicMaterial({map:textTex('PLAYSAFE','#b6f7cf',512,100,'800 70px sans-serif'),transparent:true})));")
rep("function jersey(){const g=new TH.Group()",
    "// the hero and the interactive jersey are the same shirt: build its heavy parts once\nconst JC={};\nfunction jersey(){const g=new TH.Group()")

# ---------- 2. grass drawn ahead of time when the browser is idle ----------
rep("scene(hv,{cam:[0,0,9.6],look:[0,-.1,0],auto:.45,drag:1},S=>{const j=jerseyStage(S,{v:-1});S.root.rotation.x=.05;hv.insertAdjacentHTML('beforeend','<div class=\"hint\">Drag to rotate</div>')});",
    "scene(hv,{cam:[0,0,9.6],look:[0,-.1,0],auto:.45,drag:1},S=>{const j=jerseyStage(S,{v:-1});S.root.rotation.x=.05;hv.insertAdjacentHTML('beforeend','<div class=\"hint\">Drag to rotate</div>')});\n"
    "// draw the grass texture ahead of time, when the browser is idle (Safari has no requestIdleCallback: use a timer)\n"
    "(window.requestIdleCallback?f=>requestIdleCallback(f,{timeout:3000}):f=>setTimeout(f,1000))(()=>{try{grassTex()}catch(e){console.warn('grass prewarm failed',e)}});")

open(P, 'w', encoding='utf-8', newline='').write(s)
print('ok', len(s.encode('utf-8')))
