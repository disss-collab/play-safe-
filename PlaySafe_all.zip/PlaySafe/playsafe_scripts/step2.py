import re, sys
P = sys.argv[1]
s = open(P, encoding='utf-8').read()

# ---------- 1. HTML ----------
R = [
 ('<p class="k" style="margin-top:18px">2 removable motion modules · upper back and pelvis · built for training first</p>',
  '<p class="k" style="margin-top:18px">2 removable motion modules · upper back and pelvis · under 20 g in total · built for training first</p>', 1),
 ('<div id="c2" class="rv"></div>\n<h2 class="rv" style="margin-top:70px">What happens after an impact?</h2><div id="c3" class="rv"></div></section>',
  '<div id="c2" class="rv"></div></section>', 1),
 ('<section><div class="k rv">Prevention over reaction</div><h2 class="rv">Don\'t wait for the injury.</h2><p class="rv" style="font-size:20px;color:var(--g2)">Detect the warning signs earlier.</p><div id="c4" class="rv"></div>\n<h2 class="rv" style="margin-top:70px">Inside PlaySafe</h2><div id="c5" class="rv"></div></section>\n',
  '', 1),
 ('\n<h2 class="rv" style="margin-top:80px">The future of football is smarter.</h2><div id="c6" class="rv"></div></section>',
  '</section>', 1),
 ("['Removable module','Under 20 g with a waterproof IP67 case. The shirt goes in the wash, the module does not.']",
  "['Removable modules','Two modules, under 20 g in total, in waterproof IP67 cases. The clothing goes in the wash, the modules do not.']", 1),
 ("['Battery for a full day','A 400 mAh battery covers training plus a match with a large reserve.']",
  "['A battery in each module','Each module has its own rechargeable battery. Target: one full training session on a single charge.']", 1),
 ("so PlaySafe starts with training.']]);",
  "so PlaySafe starts with training.'],['v2 · after the pilot','Anomaly-detection models trained on pilot data.']]);", 1),
]
for old, new, n in R:
    c = s.count(old)
    if c != n:
        sys.exit(f'replace: expected {n}, found {c}: {old[:70]!r}')
    s = s.replace(old, new)

# ---------- 2. chains: new c2, drop c3..c6 ----------
NEWC2 = ("chain('c2',[['Two modules','Upper back and shorts waistband record movement, impacts, sprints and direction changes.'],"
 "['Impact detected','A strong hit or fall is found when acceleration crosses a threshold.'],"
 "['Personal normal',\"Each player's usual movement is learned from earlier sessions.\"],"
 "['Compare','Movement after the impact is compared with that normal (z-score).'],"
 "['Status','Normal, Monitor or Check.'],"
 "['Staff decide','The coach gets a simple alert. People make the final decision.']]);")
lines = s.split('\n')
out = []
seen = set()
for ln in lines:
    m = re.match(r"chain\('(c\d)',", ln)
    if m and m.group(1) in ('c2', 'c3', 'c4', 'c5', 'c6'):
        seen.add(m.group(1))
        if m.group(1) == 'c2':
            out.append(NEWC2)
        continue
    out.append(ln)
if seen != {'c2', 'c3', 'c4', 'c5', 'c6'}:
    sys.exit(f'chains found: {seen}')
s = '\n'.join(out)

# ---------- 3. dictionary: remove unused ----------
REMOVE = ['Sensor modules', 'Two small removable modules collect movement and impact data.', 'Real-time data',
 'Data is sent to the PlaySafe system.', 'AI analysis', 'AI analyzes movement, workload and impact patterns.',
 'Risk detection', 'The system identifies unusual patterns that may need attention.', 'Coach alert',
 'The coach receives a simple and understandable alert.', 'What happens after an impact?',
 'A strong hit is recorded by the jersey.', 'Data received', 'The signal reaches the system in real time.',
 "Movement is compared with the player's normal pattern.", 'Movement change', 'A difference from normal is found.',
 'The player is marked Normal, Monitor or Check.', 'The staff gets a check recommendation.',
 'Prevention over reaction', "Don't wait for the injury.", 'Detect the warning signs earlier.', 'High load',
 'Heavy workload builds up over days.', 'Small changes in how the player moves appear.', 'AI detection',
 'The system sees the pattern early.', 'Staff get an early signal to check.', 'Player check',
 'A professional assesses the player.', 'Inside PlaySafe', 'The athlete on the field.', 'PlaySafe jersey',
 'A normal compression shirt with a pocket for the module.', 'Sensors',
 'Two motion sensors: upper back and pelvis. Heart rate and temperature: optional, later.',
 'Fast, secure data stream.', 'AI engine', 'Finds unusual movement patterns.', 'Risk analysis',
 'Potential risk level for each player.', 'Coach / medical team', 'People make the final decision.',
 'The future of football is smarter.', 'Today · Smart jersey', 'Sensors and live monitoring for teams.',
 'Next · AI player profiles', 'Personal movement baselines for every player.', 'Future · Smarter early warning',
 'Earlier warnings from long-term patterns.', 'Vision · Safer football',
 'More players on the field, fewer long injuries.',
 '2 removable motion modules · upper back and pelvis · built for training first', 'Removable module',
 'Under 20 g with a waterproof IP67 case. The shirt goes in the wash, the module does not.',
 'Battery for a full day', 'A 400 mAh battery covers training plus a match with a large reserve.']
a, b = s.index('const DD=['), s.index('const D=Object.fromEntries')
dd = s[a:b]
for k in REMOVE:
    pat = r"\[(['\"])" + re.escape(k) + r"\1(?:,(['\"]).*?\2){3}\],?\n?"
    m = list(re.finditer(pat, dd))
    if len(m) != 1:
        sys.exit(f'DD remove {k!r}: {len(m)} matches')
    dd = dd[:m[0].start()] + dd[m[0].end():]
s = s[:a] + dd + s[b:]
# safety: removed keys must not be used anywhere outside the dictionary
rest = s[:s.index('const DD=[')] + s[s.index('const D=Object.fromEntries'):]
for k in REMOVE:
    for q in ("'", '"', '>'):
        if (q + k + ("<" if q == '>' else q)) in rest:
            sys.exit(f'still used: {k!r}')

# ---------- 4. new dictionary entries ----------
NEW = r'''['2 removable motion modules · upper back and pelvis · under 20 g in total · built for training first','2 съёмных модуля движения · верх спины и таз · вместе до 20 г · сначала для тренировок','2 个可拆卸运动模块 · 上背部和骨盆 · 合计不到 20 克 · 先用于训练','2 алынбалы қозғалыс модулі · жоғарғы арқа және жамбас · барлығы 20 г-дан аз · алдымен жаттығуға'],
['Two modules','Два модуля','两个模块','Екі модуль'],['Upper back and shorts waistband record movement, impacts, sprints and direction changes.','Модули на верху спины и на поясе шорт записывают движение, удары, спринты и смены направления.','上背部和短裤腰带上的模块记录运动、撞击、冲刺和变向。','Жоғарғы арқадағы және шорт белдігіндегі модульдер қозғалысты, соққыларды, спринттерді және бағыт өзгерісін жазады.'],
['A strong hit or fall is found when acceleration crosses a threshold.','Сильный удар или падение определяется, когда ускорение превышает порог.','当加速度超过阈值时，系统识别出强烈撞击或摔倒。','Үдеу шектен асқанда күшті соққы не құлау анықталады.'],
['Personal normal','Личная норма','个人常态','Жеке норма'],["Each player's usual movement is learned from earlier sessions.",'Обычное движение каждого игрока определяется по прошлым тренировкам.','根据以往训练得出每位球员的常规运动。','Әр ойыншының әдеттегі қозғалысы бұрынғы жаттығулар бойынша анықталады.'],
['Compare','Сравнение','对比','Салыстыру'],['Movement after the impact is compared with that normal (z-score).','Движение после удара сравнивается с этой нормой (z-оценка).','将撞击后的运动与该常态对比（z 分数）。','Соққыдан кейінгі қозғалыс осы нормамен салыстырылады (z-бағалау).'],
['Normal, Monitor or Check.','«Норма», «Наблюдение» или «Проверка».','正常、关注或检查。','«Қалыпты», «Бақылау» не «Тексеру».'],
['Staff decide','Решает персонал','由工作人员决定','Шешімді қызметкерлер қабылдайды'],['The coach gets a simple alert. People make the final decision.','Тренер получает простой сигнал. Окончательное решение принимают люди.','教练收到简单的提示，最终由人来做决定。','Жаттықтырушы қарапайым ескерту алады. Соңғы шешімді адамдар қабылдайды.'],
['v2 · after the pilot','v2 · после пилота','v2 · 试点之后','v2 · пилоттан кейін'],['Anomaly-detection models trained on pilot data.','Модели поиска аномалий, обученные на данных пилота.','基于试点数据训练的异常检测模型。','Пилот деректерінде оқытылған ауытқуларды іздеу модельдері.'],
['Removable modules','Съёмные модули','可拆卸模块','Алынбалы модульдер'],['Two modules, under 20 g in total, in waterproof IP67 cases. The clothing goes in the wash, the modules do not.','Два модуля, вместе менее 20 г, во влагозащищённых корпусах IP67. Одежда идёт в стирку, модули — нет.','两个模块合计不到 20 克，采用 IP67 防水外壳。衣服可以洗，模块不用洗。','Екі модуль, барлығы 20 г-дан аз, IP67 су өткізбейтін корпуста. Киім жуылады, модульдер жуылмайды.'],
['A battery in each module','Своя батарея в каждом модуле','每个模块自带电池','Әр модульде өз батареясы'],['Each module has its own rechargeable battery. Target: one full training session on a single charge.','У каждого модуля свой аккумулятор. Цель: одна полная тренировка на одном заряде.','每个模块都有自己的充电电池。目标：充一次电支持一整场训练。','Әр модульдің өз аккумуляторы бар. Мақсат: бір зарядпен бір толық жаттығу.']'''
a = s.index('const D=Object.fromEntries')
end = s.rindex('];', 0, a)
s = s[:end].rstrip().rstrip(',') + ',\n' + NEW + s[end:]
open(P, 'w', encoding='utf-8', newline='').write(s)
print('ok', len(s.encode('utf-8')))
