import sys
P = sys.argv[1]
s = open(P, encoding='utf-8').read()

def rep(old, new, n=1):
    global s
    c = s.count(old)
    if c != n:
        sys.exit(f'expected {n}, found {c}: {old[:80]!r}')
    s = s.replace(old, new)

# ---- phone flag ----
rep("const TH=THREE,RM=matchMedia('(prefers-reduced-motion: reduce)').matches,GR=0x1fdc6a,rnd=Math.random;",
    "const TH=THREE,RM=matchMedia('(prefers-reduced-motion: reduce)').matches,GR=0x1fdc6a,rnd=Math.random,MOB=matchMedia('(max-width: 700px), (pointer: coarse)').matches;")

# ---- 4b: grass drawn once, half size on phones (same density of speckles) ----
rep("function grassTex(){const t=new TH.CanvasTexture(cvs(2048,1366,(x,w,h)=>{",
    "let GRASS;function grassTex(){if(GRASS)return GRASS;const k=MOB?.5:1,t=new TH.CanvasTexture(cvs(2048*k|0,1366*k|0,x=>{x.scale(k,k);const w=2048,h=1366;")
rep("for(let i=0;i<30000;i++){x.fillStyle='rgba('", "for(let i=0,N=Math.round(30000*k*k);i<N;i++){x.fillStyle='rgba('")
rep(" t.anisotropy=8;return t}", " t.anisotropy=8;return GRASS=t}")

# ---- 4c: phone render settings ----
rep("r.setPixelRatio(Math.min(devicePixelRatio||1,2));", "r.setPixelRatio(Math.min(devicePixelRatio||1,MOB?1.5:2));")
rep("key.shadow.mapSize.set(1024,1024);", "key.shadow.mapSize.setScalar(MOB?512:1024);")

# ---- fade 2D -> 3D (0.3 s) + lazy start ----
rep("""function scene(host,o,build){let S;const fb=()=>{if(S){S.dead=true;try{S.r.domElement.remove();S.r.dispose()}catch(_){}}const v=host.querySelector('svg');if(v)v.style.display=''};
 try{S=stage(host,o);S.fail=fb;build(S);const v=host.querySelector('svg');if(v)v.style.display='none'}catch(e){console.warn('3D scene failed',e);fb()}return S}""",
"""function scene(host,o,build){let S;const v=host.querySelector('svg'),fb=()=>{if(S){S.dead=true;try{S.r.domElement.remove();S.r.dispose()}catch(_){}}if(v){v.style.display='';v.style.opacity=''}};
 try{S=stage(host,o);S.fail=fb;build(S);const c=S.r.domElement;c.style.opacity=0;c.style.transition='opacity .3s';if(v)v.style.transition='opacity .3s';
  requestAnimationFrame(()=>requestAnimationFrame(()=>{if(S.dead)return;c.style.opacity=1;if(v){v.style.opacity=0;setTimeout(()=>{if(!S.dead)v.style.display='none'},320)}}))}catch(e){console.warn('3D scene failed',e);fb()}return S}
// start a 3D scene only when its section comes near the screen; until then the 2D version is shown
function lazy(host,f){if(!window.IntersectionObserver)return f();const io=new IntersectionObserver(e=>{if(e.some(x=>x.isIntersecting)){io.disconnect();f()}},{rootMargin:'300px 0px'});io.observe(host)}""")

# scene 2: jersey (keeps the side chosen in 2D)
rep("scene(jh,{cam:[0,0,9.6],look:[0,-.1,0],drag:1},S=>{const sel={v:-1}", "lazy(jh,()=>scene(jh,{cam:[0,0,9.6],look:[0,-.1,0],drag:1},S=>{const sel={v:-1}")
rep("S.tg=b+Math.round((r-b)/(2*Math.PI))*2*Math.PI};S.root.rotation.y=Math.PI});",
    "S.tg=b+Math.round((r-b)/(2*Math.PI))*2*Math.PI};const sd=document.querySelector('#side button.on');S.root.rotation.y=sd&&sd.dataset.s=='f'?0:Math.PI}));")
# scene 3: hologram (keeps the zone chosen in 2D)
rep("scene(ah,{cam:[0,0,10.6],look:[0,0,0],drag:1,auto:.22},S=>{", "lazy(ah,()=>scene(ah,{cam:[0,0,10.6],look:[0,0,0],drag:1,auto:.22},S=>{")
rep("let za=1;S.upd.push(", "let za=Math.max(0,[...document.querySelectorAll('.zn')].findIndex(c=>c.classList.contains('s')));S.upd.push(")
rep("S.pick(hits,i=>{za=i;zi(i)})});", "S.pick(hits,i=>{za=i;zi(i)})}));")
# scene 4: live pitch (keeps the player chosen in 2D)
rep("scene(pt,{cam:[0,7.6,8.8],look:[0,0,.3],drag:1,shadow:1,fog:[16,34]},S=>{", "lazy(pt,()=>scene(pt,{cam:[0,7.6,8.8],look:[0,0,.3],drag:1,shadow:1,fog:[16,34]},S=>{")
rep("const fg={},rings={};let selN=9;", "const fg={},rings={},s0=document.querySelector('.pl.s');let selN=s0?+s0.dataset.n:9;")
rep("const _s=sel;sel=n=>{_s(n);selN=n};sel(selN)});", "const _s=sel;sel=n=>{_s(n);selN=n};sel(selN)}));")
# scene 5: impact demo
rep("scene(dm,{cam:[0,4.7,8.2],look:[0,.7,0],shadow:1,fog:[14,30]},S=>{", "lazy(dm,()=>scene(dm,{cam:[0,4.7,8.2],look:[0,.7,0],shadow:1,fog:[14,30]},S=>{")
rep("$('#rst').addEventListener('click',r0)});", "$('#rst').addEventListener('click',r0)}));")

# ---- 4d: chart labels at least ~12 px on screen ----
rep("function zr(){const a=ZD[zp],", "function zr(){const fs=Math.min(26,Math.max(18,Math.ceil(12.5*600/($('#zc').clientWidth||600)))),a=ZD[zp],")
rep('<text x="42" y="${Y(t)+6}" text-anchor="end" font-size="18" fill="#9db1a5">${t}</text>',
    '<text x="46" y="${Y(t)+fs*.35}" text-anchor="end" font-size="${fs}" fill="#9db1a5">${t}</text>')
rep('<text x="${(X(0)+X(11))/2}" y="324" text-anchor="middle" font-size="20" fill="#9db1a5">Earlier sessions</text><text x="553" y="324" text-anchor="middle" font-size="20" fill="#fff">Today</text>',
    '<text x="${(X(0)+X(11))/2}" y="${294+fs}" text-anchor="middle" font-size="${fs}" fill="#9db1a5">Earlier sessions</text><text x="598" y="${294+fs}" text-anchor="end" font-size="${fs}" fill="#fff">Today</text>')
rep("zp=+b.dataset.p;zr()});zr();",
    "zp=+b.dataset.p;zr()});zr();\nif(window.ResizeObserver){let zw=0;new ResizeObserver(e=>{const w=Math.round(e[0].contentRect.width);if(w!==zw){zw=w;zr()}}).observe($('#zc'))}")

open(P, 'w', encoding='utf-8', newline='').write(s)
print('ok', len(s.encode('utf-8')))
